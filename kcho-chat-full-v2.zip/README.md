# K'Cho Chat (Offline Local Wi-Fi Mesh Messenger)

Database နှင့် Internet မလိုဘဲ Wi-Fi Router သို့မဟုတ် Mobile Hotspot တစ်ခုတည်းပေါ်ရှိ စက်များကြား တိုက်ရိုက်ဆက်သွယ်နိုင်သော Android App ဖြစ်ပါသည်။

## ပါဝင်သော Features များ
- **Auto-Discovery & @ID Search**: Wi-Fi တူသူများကို အလိုအလျောက် ရှာဖွေပေးပြီး နာမည်၊ `@username` ID သို့မဟုတ် Local IP ဖြင့် ရှာဖွေနိုင်ခြင်း
- **Group Chat & Direct Chat**: Wi-Fi တစ်ခုလုံးရှိ လူအားလုံးပါဝင်သော Group Chat နှင့် တစ်ဦးချင်း Direct Chat
- **Live Walkie-Talkie Voice Call**: `Hold` ခလုတ်နှိပ်ထားစဉ် UDP Audio Stream (16kHz PCM) ဖြင့် တိုက်ရိုက် အသံထုတ်လွှင့်/နားထောင်နိုင်ခြင်း
- **Photo & Video Sharing**: Built-in Local HTTP Server (Port 8080) မှတစ်ဆင့် ပုံနှင့် Video ဖိုင်များကို တိုက်ရိုက် ပို့/လက်ခံနိုင်ခြင်း

## APK တည်ဆောက်ပုံ
1. ဤ Project ကို GitHub Repository အသစ်တစ်ခုထဲ တင်ပါ။
2. GitHub **Actions** tab ထဲဝင်ပြီး **Build K'Cho Chat Debug APK** workflow ကို run ပါ။
3. Build ပြီးပါက Artifacts ထဲမှ `KCho-Chat-Debug-APK` ကို ဒေါင်းလုဒ်ဆွဲပြီး ဖုန်းများတွင် Install လုပ်ပါ။
