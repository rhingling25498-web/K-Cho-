package com.daily.kchochat;

import android.Manifest;
import android.content.Context;
import android.media.MediaRecorder;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.Build;
import android.util.Base64;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "KchoMesh", permissions = {
    @Permission(alias = "microphone", strings = { Manifest.permission.RECORD_AUDIO })
})
public class KchoMeshPlugin extends Plugin {
    private static final int PORT = 39876;
    private static final int MEDIA_PORT = 39877;
    private static final long MAX_MEDIA_BYTES = 100L * 1024L * 1024L;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean mediaServerRunning = new AtomicBoolean(false);
    private DatagramSocket socket;
    private Thread receiver;
    private Thread mediaServer;
    private ServerSocket mediaSocket;
    private WifiManager.MulticastLock multicastLock;
    private MediaRecorder recorder;
    private File recordingFile;

    @PluginMethod public void startService(PluginCall call) {
        try {
            acquireMulticastLock();
            if (!running.get()) {
                socket = new DatagramSocket(null);
                socket.setReuseAddress(true); socket.setBroadcast(true);
                socket.bind(new InetSocketAddress(PORT));
                running.set(true);
                receiver = new Thread(this::receiveLoop, "KChoMesh-UDP"); receiver.start();
            }
            JSObject result = new JSObject(); result.put("ip", getLocalIp()); result.put("port", PORT); call.resolve(result);
        } catch (Exception e) { call.reject("Unable to start nearby discovery: " + e.getMessage(), e); }
    }

    @PluginMethod public void sendPacket(PluginCall call) {
        String payload = call.getString("payload"); String target = call.getString("targetIp", "255.255.255.255");
        if (payload == null) { call.reject("payload is required"); return; }
        try {
            if (socket == null || socket.isClosed()) { call.reject("Nearby service is not running"); return; }
            byte[] bytes = payload.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > 60000) { call.reject("Packet is too large"); return; }
            if ("255.255.255.255".equals(target) || "<broadcast>".equalsIgnoreCase(target)) {
                int sent = 0;
                for (InetAddress broadcast : getBroadcastAddresses()) {
                    socket.send(new DatagramPacket(bytes, bytes.length, broadcast, PORT));
                    sent++;
                }
                // Keep a global broadcast fallback for unusual Wi-Fi/hotspot interfaces.
                if (sent == 0) socket.send(new DatagramPacket(bytes, bytes.length, InetAddress.getByName("255.255.255.255"), PORT));
            } else {
                socket.send(new DatagramPacket(bytes, bytes.length, InetAddress.getByName(target), PORT));
            }
            call.resolve();
        } catch (Exception e) { call.reject("UDP send failed: " + e.getMessage(), e); }
    }

    @PluginMethod public void requestMicrophonePermission(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) { call.resolve(); return; }
        requestPermissionForAlias("microphone", call, "microphonePermissionResult");
    }
    @PermissionCallback private void microphonePermissionResult(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) call.resolve();
        else call.reject("Microphone permission was not granted");
    }

    @PluginMethod public void startRecording(PluginCall call) {
        try {
            if (getPermissionState("microphone") != PermissionState.GRANTED) { call.reject("Microphone permission is required"); return; }
            if (recorder != null) { call.reject("A recording is already in progress"); return; }
            recordingFile = new File(getContext().getCacheDir(), "kcho-voice-" + UUID.randomUUID() + ".m4a");
            recorder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? new MediaRecorder(getContext()) : new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(64000); recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(recordingFile.getAbsolutePath()); recorder.prepare(); recorder.start();
            JSObject out = new JSObject(); out.put("started", true); call.resolve(out);
        } catch (Exception e) { releaseRecorder(); call.reject("Could not start voice recording: " + e.getMessage(), e); }
    }

    @PluginMethod public void stopRecording(PluginCall call) {
        try {
            if (recorder == null || recordingFile == null) { call.reject("No active recording"); return; }
            recorder.stop(); recorder.reset(); recorder.release(); recorder = null;
            byte[] bytes = readAll(new FileInputStream(recordingFile));
            recordingFile.delete(); recordingFile = null;
            JSObject out = new JSObject(); out.put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP));
            out.put("mimeType", "audio/mp4"); out.put("fileName", "voice-" + System.currentTimeMillis() + ".m4a");
            call.resolve(out);
        } catch (Exception e) { releaseRecorder(); call.reject("Recording was too short or could not be saved: " + e.getMessage(), e); }
    }

    @PluginMethod public void hostMediaBase64(PluginCall call) {
        try {
            String b64 = call.getString("base64"); String fileName = call.getString("fileName", "media.bin");
            String mimeType = call.getString("mimeType", "application/octet-stream");
            if (b64 == null || b64.isEmpty()) { call.reject("Media data is empty"); return; }
            if (!(mimeType.startsWith("image/") || mimeType.startsWith("video/") || mimeType.startsWith("audio/"))
                || !mimeType.matches("[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+")) {
                call.reject("Only valid image, video, and audio files can be shared"); return;
            }
            long estimatedBytes = (long) (b64.length() * 0.75);
            if (estimatedBytes > MAX_MEDIA_BYTES) { call.reject("Media is larger than 100 MB"); return; }
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            if (bytes.length == 0 || bytes.length > MAX_MEDIA_BYTES) { call.reject("Media file size is invalid or exceeds 100 MB"); return; }
            String localIp = getLocalIp();
            if ("0.0.0.0".equals(localIp)) { call.reject("Could not find this phone's Wi-Fi or hotspot IP address"); return; }
            String id = UUID.randomUUID().toString(); File dir = new File(getContext().getCacheDir(), "kcho-shared-media");
            if (!dir.exists() && !dir.mkdirs()) { call.reject("Could not create temporary media folder"); return; }
            File outFile = new File(dir, id + ".bin");
            File metaFile = new File(dir, id + ".mime");
            try (FileOutputStream out = new FileOutputStream(outFile)) { out.write(bytes); }
            try (FileOutputStream out = new FileOutputStream(metaFile)) { out.write(mimeType.getBytes(StandardCharsets.UTF_8)); }
            startMediaServer();
            JSObject out = new JSObject(); out.put("url", "http://" + localIp + ":" + MEDIA_PORT + "/media/" + id);
            out.put("fileName", fileName); out.put("size", bytes.length); call.resolve(out);
        } catch (Exception e) { call.reject("Unable to share media: " + e.getMessage(), e); }
    }

    @PluginMethod public void fetchMediaAsBase64(PluginCall call) {
        String url = call.getString("url"); String expectedHost = call.getString("expectedHost");
        if (url == null || expectedHost == null) { call.reject("Media URL and sender address are required"); return; }
        HttpURLConnection c = null;
        try {
            URL parsed = new URL(url);
            if (!"http".equalsIgnoreCase(parsed.getProtocol()) || !expectedHost.equals(parsed.getHost()) || parsed.getPort() != MEDIA_PORT || !parsed.getPath().matches("/media/[A-Fa-f0-9-]{36}")) {
                call.reject("Media address does not match the nearby sender"); return;
            }
            c = (HttpURLConnection) parsed.openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(60000);
            c.setRequestMethod("GET"); c.setRequestProperty("Accept-Encoding", "identity");
            int status = c.getResponseCode();
            if (status != 200) { call.reject("Media download failed: HTTP " + status); return; }
            int declaredLength = c.getContentLength();
            if (declaredLength > MAX_MEDIA_BYTES) { call.reject("Received media is larger than 100 MB"); return; }
            byte[] bytes;
            try (InputStream input = c.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[32768]; int count; long total = 0;
                while ((count = input.read(buffer)) != -1) {
                    total += count; if (total > MAX_MEDIA_BYTES) throw new IOException("Received media is larger than 100 MB");
                    output.write(buffer, 0, count);
                }
                bytes = output.toByteArray();
            }
            JSObject out = new JSObject(); out.put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP));
            out.put("size", bytes.length); out.put("contentType", c.getContentType()); call.resolve(out);
        } catch (Exception e) { call.reject("Unable to receive media: " + e.getMessage(), e); }
        finally { if (c != null) c.disconnect(); }
    }

    @PluginMethod public void saveMediaToDownloads(PluginCall call) {
        try {
            String b64 = call.getString("base64"); String name = call.getString("fileName", "kcho-media");
            if (b64 == null) { call.reject("base64 is required"); return; }
            File dir = getContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS); if (dir == null) dir = getContext().getFilesDir();
            File f = new File(dir, name.replaceAll("[^A-Za-z0-9._-]", "_"));
            try (FileOutputStream out = new FileOutputStream(f)) { out.write(Base64.decode(b64, Base64.DEFAULT)); }
            JSObject result = new JSObject(); result.put("path", f.getAbsolutePath()); call.resolve(result);
        } catch (Exception e) { call.reject("Unable to save media: " + e.getMessage(), e); }
    }

    private synchronized void startMediaServer() throws IOException {
        if (mediaServerRunning.get()) return;
        mediaSocket = new ServerSocket(); mediaSocket.setReuseAddress(true); mediaSocket.bind(new InetSocketAddress("0.0.0.0", MEDIA_PORT));
        mediaServerRunning.set(true);
        mediaServer = new Thread(() -> {
            while (mediaServerRunning.get()) {
                try { final Socket client = mediaSocket.accept(); new Thread(() -> serveMedia(client), "KChoMediaClient").start(); }
                catch (Exception e) { if (mediaServerRunning.get()) android.util.Log.w("KchoMesh", "Media server error", e); }
            }
        }, "KChoMediaServer"); mediaServer.start();
    }
    private void serveMedia(Socket client) {
        try (Socket s = client) {
            s.setSoTimeout(10000);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.US_ASCII));
            OutputStream out = s.getOutputStream();
            String request = in.readLine(); if (request == null) return; String[] parts = request.split(" ");
            String line; while ((line = in.readLine()) != null && !line.isEmpty()) {}
            if (parts.length < 2 || !"GET".equals(parts[0]) || !parts[1].matches("/media/[A-Fa-f0-9-]{36}")) {
                writeHttpError(out, 404, "Not Found"); return;
            }
            String id = parts[1].substring("/media/".length());
            File dir = new File(getContext().getCacheDir(), "kcho-shared-media");
            File f = new File(dir, id + ".bin"); File mimeFile = new File(dir, id + ".mime");
            if (!f.isFile() || !mimeFile.isFile()) { writeHttpError(out, 404, "Not Found"); return; }
            String mime = new String(readAll(new FileInputStream(mimeFile)), StandardCharsets.UTF_8);
            if (!(mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/"))) mime = "application/octet-stream";
            String header = "HTTP/1.1 200 OK\r\nContent-Type: " + mime + "\r\nContent-Length: " + f.length() + "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
            out.write(header.getBytes(StandardCharsets.US_ASCII));
            try (InputStream media = new FileInputStream(f)) { byte[] buffer = new byte[32768]; int count; while ((count = media.read(buffer)) != -1) out.write(buffer, 0, count); }
            out.flush();
        } catch (Exception e) { android.util.Log.w("KchoMesh", "Media request failed", e); }
    }
    private void writeHttpError(OutputStream out, int status, String reason) throws IOException {
        byte[] body = new byte[0];
        String header = "HTTP/1.1 " + status + " " + reason + "\r\nContent-Type: text/plain\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
        out.write(header.getBytes(StandardCharsets.US_ASCII)); out.write(body); out.flush();
    }
    private byte[] readAll(InputStream in) throws IOException {
        try (InputStream source = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) { byte[] b = new byte[16384]; int n; while ((n = source.read(b)) != -1) out.write(b, 0, n); return out.toByteArray(); }
    }
    private void releaseRecorder() {
        if (recorder != null) { try { recorder.reset(); } catch (Exception ignored) {} try { recorder.release(); } catch (Exception ignored) {} recorder = null; }
        if (recordingFile != null) { recordingFile.delete(); recordingFile = null; }
    }
    private void receiveLoop() {
        byte[] buffer = new byte[60000];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        while (running.get() && socket != null && !socket.isClosed()) {
            try { packet.setLength(buffer.length); socket.receive(packet);
                String payload = new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
                JSObject event = new JSObject(); event.put("payload", payload); event.put("senderIp", packet.getAddress().getHostAddress()); notifyListeners("onPacket", event);
            } catch (Exception e) { if (running.get()) android.util.Log.w("KchoMesh", "UDP receive failed", e); }
        }
    }
    private void acquireMulticastLock() {
        try { WifiManager wifi = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null && multicastLock == null) { multicastLock = wifi.createMulticastLock("KChoChatMulticast"); multicastLock.setReferenceCounted(false); multicastLock.acquire(); }
        } catch (Exception e) { android.util.Log.w("KchoMesh", "Multicast lock unavailable", e); }
    }
    private boolean isPreferredWifiInterface(NetworkInterface ni) {
        String name = ni.getName() == null ? "" : ni.getName().toLowerCase(java.util.Locale.US);
        return name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("swlan") || name.contains("wifi");
    }

    private NetworkInterface getActiveNetworkInterface() throws SocketException {
        java.util.List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
        // Prefer Android Wi-Fi / hotspot interfaces; avoid VPN and cellular addresses.
        for (NetworkInterface ni : interfaces) {
            if (ni.isUp() && !ni.isLoopback() && isPreferredWifiInterface(ni)) {
                for (InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return ni;
            }
        }
        // Fallback for devices whose Wi-Fi interface has a vendor-specific name.
        for (NetworkInterface ni : interfaces) {
            String name = ni.getName() == null ? "" : ni.getName().toLowerCase(java.util.Locale.US);
            if (!ni.isUp() || ni.isLoopback() || name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("pdp") || name.startsWith("tun") || name.startsWith("dummy")) continue;
            for (InetAddress a : Collections.list(ni.getInetAddresses()))
                if (a instanceof Inet4Address && !a.isLoopbackAddress()) return ni;
        }
        return null;
    }

    private java.util.List<InetAddress> getBroadcastAddresses() {
        java.util.LinkedHashMap<String, InetAddress> result = new java.util.LinkedHashMap<>();
        try {
            NetworkInterface preferred = getActiveNetworkInterface();
            if (preferred != null) {
                for (InterfaceAddress address : preferred.getInterfaceAddresses()) {
                    InetAddress broadcast = address.getBroadcast();
                    if (broadcast instanceof Inet4Address) result.put(broadcast.getHostAddress(), broadcast);
                }
            }
            // Include broadcasts from other active LAN interfaces (e.g. vendor hotspot bridges).
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String name = ni.getName() == null ? "" : ni.getName().toLowerCase(java.util.Locale.US);
                if (!(isPreferredWifiInterface(ni) || name.startsWith("eth"))) continue;
                for (InterfaceAddress address : ni.getInterfaceAddresses()) {
                    InetAddress broadcast = address.getBroadcast();
                    if (broadcast instanceof Inet4Address) result.put(broadcast.getHostAddress(), broadcast);
                }
            }
        } catch (Exception e) { android.util.Log.w("KchoMesh", "Could not determine LAN broadcast address", e); }
        return new java.util.ArrayList<>(result.values());
    }

    private String getLocalIp() {
        try {
            NetworkInterface ni = getActiveNetworkInterface();
            if (ni != null) for (InetAddress a : Collections.list(ni.getInetAddresses()))
                if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
        } catch (Exception e) { android.util.Log.w("KchoMesh", "Could not determine local Wi-Fi IP", e); }
        return "0.0.0.0";
    }
    @Override protected void handleOnDestroy() {
        running.set(false); if (socket != null) socket.close(); mediaServerRunning.set(false);
        if (mediaSocket != null) try { mediaSocket.close(); } catch (Exception ignored) {}
        releaseRecorder(); if (multicastLock != null && multicastLock.isHeld()) multicastLock.release(); super.handleOnDestroy();
    }
}
