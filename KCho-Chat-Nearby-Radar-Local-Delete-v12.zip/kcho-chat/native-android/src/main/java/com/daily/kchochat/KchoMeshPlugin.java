package com.daily.kchochat;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Build;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "KchoMesh")
public class KchoMeshPlugin extends Plugin {
    private static final int PORT = 39876;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private DatagramSocket socket;
    private Thread receiver;
    private WifiManager.MulticastLock multicastLock;

    @PluginMethod
    public void startService(PluginCall call) {
        try {
            acquireMulticastLock();
            if (!running.get()) {
                socket = new DatagramSocket(null);
                socket.setReuseAddress(true);
                socket.setBroadcast(true);
                socket.bind(new InetSocketAddress(PORT));
                running.set(true);
                receiver = new Thread(this::receiveLoop, "KChoMesh-UDP");
                receiver.start();
            }
            JSObject result = new JSObject();
            result.put("ip", getLocalIp());
            result.put("port", PORT);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Unable to start nearby discovery: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void sendPacket(PluginCall call) {
        String payload = call.getString("payload");
        String target = call.getString("targetIp", "255.255.255.255");
        if (payload == null) { call.reject("payload is required"); return; }
        try {
            if (socket == null || socket.isClosed()) {
                call.reject("Nearby service is not running"); return;
            }
            byte[] bytes = payload.getBytes(StandardCharsets.UTF_8);
            InetAddress address = InetAddress.getByName(target);
            DatagramPacket packet = new DatagramPacket(bytes, bytes.length, address, PORT);
            socket.send(packet);
            call.resolve();
        } catch (Exception e) {
            call.reject("UDP send failed: " + e.getMessage(), e);
        }
    }

    private void receiveLoop() {
        byte[] buffer = new byte[65507];
        while (running.get() && socket != null && !socket.isClosed()) {
            try {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);
                String payload = new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
                JSObject event = new JSObject();
                event.put("payload", payload);
                event.put("senderIp", packet.getAddress().getHostAddress());
                notifyListeners("onPacket", event);
            } catch (Exception e) {
                if (running.get()) android.util.Log.w("KchoMesh", "UDP receive failed", e);
            }
        }
    }

    private void acquireMulticastLock() {
        try {
            WifiManager wifi = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null && multicastLock == null) {
                multicastLock = wifi.createMulticastLock("KChoChatMulticast");
                multicastLock.setReferenceCounted(false);
                multicastLock.acquire();
            }
        } catch (Exception e) {
            android.util.Log.w("KchoMesh", "Multicast lock unavailable", e);
        }
    }

    private String getLocalIp() {
        try {
            for (NetworkInterface ni : java.util.Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress address : java.util.Collections.list(ni.getInetAddresses())) {
                    if (address instanceof Inet4Address && !address.isLoopbackAddress()) return address.getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return "0.0.0.0";
    }

    @Override
    protected void handleOnDestroy() {
        running.set(false);
        if (socket != null) socket.close();
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        super.handleOnDestroy();
    }
}
