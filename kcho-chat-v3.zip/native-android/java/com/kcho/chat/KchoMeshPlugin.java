package com.kcho.chat;

import android.Manifest;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.net.wifi.WifiManager;
import android.util.Base64;
import android.util.Log;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@CapacitorPlugin(
    name = "KchoMesh",
    permissions = {
        @Permission(alias = "audio", strings = { Manifest.permission.RECORD_AUDIO })
    }
)
public class KchoMeshPlugin extends Plugin {
    private static final String TAG = "KchoMeshPlugin";
    private static final int DISCOVERY_PORT = 41234;
    private static final int VOICE_PORT = 41235;
    private static final int HTTP_PORT = 8080;

    private static final int SAMPLE_RATE = 16000;
    private static final int CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO;
    private static final int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;

    private volatile boolean running = false;
    private volatile boolean isTalking = false;
    private volatile String voiceTargetIp = "255.255.255.255";

    private String myName = "Salai K'Cho";
    private String myHandle = "@kcho_01";
    private String myIp = "0.0.0.0";
    private String subnetBroadcastIp = "255.255.255.255";

    private DatagramSocket controlSocket;
    private DatagramSocket voiceSocket;
    private ServerSocket httpServerSocket;
    private WifiManager.MulticastLock multicastLock;
    private ScheduledExecutorService scheduler;

    private final Map<String, File> sharedFiles = new ConcurrentHashMap<>();
    private final Map<String, String> sharedMimeTypes = new ConcurrentHashMap<>();
    private final Set<String> knownPeerIps = Collections.newSetFromMap(new ConcurrentHashMap<>());

    @PluginMethod
    public void startMesh(PluginCall call) {
        myName = call.getString("name", "Salai K'Cho");
        myHandle = call.getString("handle", "@kcho_01");
        refreshNetworkInfo();

        if (!running) {
            running = true;
            acquireMulticastLock();
            startControlListener();
            startVoiceListener();
            startHttpServer();
            startDiscoveryBroadcaster();
        } else {
            broadcastPresence();
        }

        JSObject ret = new JSObject();
        ret.put("ip", myIp);
        ret.put("broadcastIp", subnetBroadcastIp);
        ret.put("status", "started");
        call.resolve(ret);
    }

    @PluginMethod
    public void updateProfile(PluginCall call) {
        myName = call.getString("name", myName);
        myHandle = call.getString("handle", myHandle);
        refreshNetworkInfo();
        broadcastPresence();

        JSObject ret = new JSObject();
        ret.put("ip", myIp);
        ret.put("broadcastIp", subnetBroadcastIp);
        call.resolve(ret);
    }

    @PluginMethod
    public void sendChatMessage(PluginCall call) {
        final String targetIp = call.getString("targetIp", "255.255.255.255");
        final String roomId = call.getString("roomId", "group_all");
        final String text = call.getString("text", "");

        new Thread(() -> {
            try {
                refreshNetworkInfo();
                JSONObject payload = new JSONObject();
                payload.put("type", "CHAT");
                payload.put("senderName", myName);
                payload.put("senderHandle", myHandle);
                payload.put("senderIp", myIp);
                payload.put("roomId", roomId);
                payload.put("text", text);
                dispatchUdpPayload(payload.toString(), targetIp);
            } catch (Exception e) {
                Log.e(TAG, "sendChatMessage error", e);
            }
        }).start();

        call.resolve();
    }

    @PluginMethod
    public void shareMediaBase64(PluginCall call) {
        final String targetIp = call.getString("targetIp", "255.255.255.255");
        final String roomId = call.getString("roomId", "group_all");
        final String fileName = call.getString("fileName", "media.bin");
        final String mimeType = call.getString("mimeType", "application/octet-stream");
        final String base64Data = call.getString("base64", "");

        new Thread(() -> {
            try {
                refreshNetworkInfo();
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                String mediaId = UUID.randomUUID().toString();
                String safeName = fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                File outFile = new File(getContext().getCacheDir(), mediaId + "_" + safeName);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(bytes);
                }
                sharedFiles.put(mediaId, outFile);
                sharedMimeTypes.put(mediaId, mimeType);

                String url = "http://" + myIp + ":" + HTTP_PORT + "/media/" + mediaId;
                JSONObject payload = new JSONObject();
                payload.put("type", "MEDIA");
                payload.put("senderName", myName);
                payload.put("senderHandle", myHandle);
                payload.put("senderIp", myIp);
                payload.put("roomId", roomId);
                payload.put("fileName", fileName);
                payload.put("mimeType", mimeType);
                payload.put("url", url);
                dispatchUdpPayload(payload.toString(), targetIp);

                JSObject ret = new JSObject();
                ret.put("url", url);
                call.resolve(ret);
            } catch (Exception e) {
                Log.e(TAG, "shareMediaBase64 error", e);
                call.reject("Media share failed: " + e.getMessage());
            }
        }).start();
    }

    @PluginMethod
    public void startVoiceBroadcast(PluginCall call) {
        if (getPermissionState("audio") != PermissionState.GRANTED) {
            requestPermissionForAlias("audio", call, "audioPermsCallback");
            return;
        }
        voiceTargetIp = call.getString("targetIp", "255.255.255.255");
        enableSpeaker();
        if (!isTalking) {
            isTalking = true;
            startAudioCaptureThread();
        }
        call.resolve();
    }

    @PermissionCallback
    private void audioPermsCallback(PluginCall call) {
        if (getPermissionState("audio") == PermissionState.GRANTED) {
            voiceTargetIp = call.getString("targetIp", "255.255.255.255");
            enableSpeaker();
            isTalking = true;
            startAudioCaptureThread();
            call.resolve();
        } else {
            call.reject("Microphone permission required for Walkie-Talkie");
        }
    }

    @PluginMethod
    public void stopVoiceBroadcast(PluginCall call) {
        isTalking = false;
        call.resolve();
    }

    private void enableSpeaker() {
        try {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setMode(AudioManager.MODE_NORMAL);
                am.setSpeakerphoneOn(true);
            }
        } catch (Exception e) {
            Log.w(TAG, "Speaker routing warning", e);
        }
    }

    private void acquireMulticastLock() {
        try {
            WifiManager wifi = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifi != null) {
                multicastLock = wifi.createMulticastLock("KchoMeshLock");
                multicastLock.setReferenceCounted(true);
                multicastLock.acquire();
            }
        } catch (Exception e) {
            Log.w(TAG, "MulticastLock warning", e);
        }
    }

    private void startDiscoveryBroadcaster() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdownNow();
        }
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(this::broadcastPresence, 0, 2, TimeUnit.SECONDS);
    }

    private void broadcastPresence() {
        try {
            refreshNetworkInfo();
            if ("0.0.0.0".equals(myIp)) return;
            JSONObject hello = new JSONObject();
            hello.put("type", "HELLO");
            hello.put("name", myName);
            hello.put("handle", myHandle);
            hello.put("ip", myIp);
            dispatchUdpPayload(hello.toString(), "255.255.255.255");
        } catch (Exception e) {
            Log.e(TAG, "broadcastPresence error", e);
        }
    }

    private Set<String> buildTargetAddresses(String targetIp) {
        Set<String> targets = new LinkedHashSet<>();
        if (targetIp != null && !targetIp.isEmpty() && !"255.255.255.255".equals(targetIp)) {
            targets.add(targetIp);
        } else {
            targets.add("255.255.255.255");
            if (subnetBroadcastIp != null && !subnetBroadcastIp.isEmpty()) {
                targets.add(subnetBroadcastIp);
            }
            targets.addAll(knownPeerIps);
        }
        return targets;
    }

    private void dispatchUdpPayload(String jsonStr, String targetIp) {
        byte[] data = jsonStr.getBytes(StandardCharsets.UTF_8);
        for (String addrStr : buildTargetAddresses(targetIp)) {
            if (addrStr.equals(myIp)) continue;
            try (DatagramSocket socket = new DatagramSocket()) {
                socket.setBroadcast(true);
                InetAddress address = InetAddress.getByName(addrStr);
                DatagramPacket packet = new DatagramPacket(data, data.length, address, DISCOVERY_PORT);
                socket.send(packet);
            } catch (Exception e) {
                Log.w(TAG, "UDP send to " + addrStr + " failed: " + e.getMessage());
            }
        }
    }

    private void startControlListener() {
        new Thread(() -> {
            try {
                if (controlSocket != null && !controlSocket.isClosed()) controlSocket.close();
                controlSocket = new DatagramSocket(DISCOVERY_PORT);
                controlSocket.setBroadcast(true);
                byte[] buf = new byte[16384];
                while (running) {
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    controlSocket.receive(packet);
                    String msg = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);
                    String packetIp = packet.getAddress() != null ? packet.getAddress().getHostAddress() : null;
                    if (packetIp != null && packetIp.equals(myIp)) continue;

                    JSONObject json = new JSONObject(msg);
                    String peerIp = json.optString("ip", json.optString("senderIp", packetIp));
                    if (peerIp != null && !peerIp.isEmpty() && !"0.0.0.0".equals(peerIp) && !peerIp.equals(myIp)) {
                        knownPeerIps.add(peerIp);
                        json.put("ip", peerIp);
                    }
                    JSObject eventData = JSObject.fromJSONObject(json);
                    notifyListeners("meshEvent", eventData);
                }
            } catch (Exception e) {
                if (running) Log.e(TAG, "Control listener error", e);
            }
        }).start();
    }

    private void startAudioCaptureThread() {
        new Thread(() -> {
            int minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, AUDIO_FORMAT);
            int bufSize = Math.max(minBuf * 2, 2048);
            AudioRecord recorder = null;
            try {
                recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, CHANNEL_IN, AUDIO_FORMAT, bufSize);
                if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioRecord failed to initialize");
                    return;
                }
                Set<InetAddress> targets = new LinkedHashSet<>();
                for (String addrStr : buildTargetAddresses(voiceTargetIp)) {
                    if (!addrStr.equals(myIp)) {
                        targets.add(InetAddress.getByName(addrStr));
                    }
                }

                byte[] buffer = new byte[1024];
                recorder.startRecording();
                try (DatagramSocket sendSocket = new DatagramSocket()) {
                    sendSocket.setBroadcast(true);
                    while (isTalking && running) {
                        int read = recorder.read(buffer, 0, buffer.length);
                        if (read > 0) {
                            for (InetAddress targetAddr : targets) {
                                DatagramPacket packet = new DatagramPacket(buffer, read, targetAddr, VOICE_PORT);
                                sendSocket.send(packet);
                            }
                        }
                    }
                }
            } catch (SecurityException se) {
                Log.e(TAG, "Mic permission missing", se);
            } catch (Exception e) {
                Log.e(TAG, "Audio capture error", e);
            } finally {
                isTalking = false;
                if (recorder != null) {
                    try {
                        if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                            recorder.stop();
                        }
                        recorder.release();
                    } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    private void startVoiceListener() {
        new Thread(() -> {
            enableSpeaker();
            int minBuf = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_OUT, AUDIO_FORMAT);
            AudioTrack track = null;
            try {
                if (voiceSocket != null && !voiceSocket.isClosed()) voiceSocket.close();
                voiceSocket = new DatagramSocket(VOICE_PORT);
                voiceSocket.setBroadcast(true);

                track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                    .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_OUT)
                        .build())
                    .setBufferSizeInBytes(Math.max(minBuf * 2, 4096))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
                track.play();

                byte[] buf = new byte[2048];
                while (running) {
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    voiceSocket.receive(packet);
                    String senderIp = packet.getAddress() != null ? packet.getAddress().getHostAddress() : null;
                    if (senderIp != null && senderIp.equals(myIp)) continue;
                    enableSpeaker();
                    track.write(packet.getData(), 0, packet.getLength());
                }
            } catch (Exception e) {
                if (running) Log.e(TAG, "Voice listener error", e);
            } finally {
                if (track != null) {
                    try { track.stop(); track.release(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    private void startHttpServer() {
        new Thread(() -> {
            try {
                if (httpServerSocket != null && !httpServerSocket.isClosed()) httpServerSocket.close();
                httpServerSocket = new ServerSocket(HTTP_PORT);
                while (running) {
                    Socket client = httpServerSocket.accept();
                    new Thread(() -> handleHttpClient(client)).start();
                }
            } catch (Exception e) {
                if (running) Log.e(TAG, "HTTP server error", e);
            }
        }).start();
    }

    private void handleHttpClient(Socket client) {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            OutputStream out = client.getOutputStream()
        ) {
            String requestLine = in.readLine();
            if (requestLine == null) return;
            String[] parts = requestLine.split(" ");
            if (parts.length < 2) return;
            String path = parts[1];

            if (path.startsWith("/media/")) {
                String mediaId = path.substring("/media/".length());
                File file = sharedFiles.get(mediaId);
                String mime = sharedMimeTypes.getOrDefault(mediaId, "application/octet-stream");
                if (file != null && file.exists()) {
                    String headers = "HTTP/1.1 200 OK\r\n" +
                        "Content-Type: " + mime + "\r\n" +
                        "Content-Length: " + file.length() + "\r\n" +
                        "Access-Control-Allow-Origin: *\r\n" +
                        "Connection: close\r\n\r\n";
                    out.write(headers.getBytes(StandardCharsets.UTF_8));
                    try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
                        byte[] buffer = new byte[8192];
                        int len;
                        while ((len = bis.read(buffer)) != -1) {
                            out.write(buffer, 0, len);
                        }
                    }
                    out.flush();
                    return;
                }
            }
            String notFound = "HTTP/1.1 404 Not Found\r\nContent-Length: 9\r\n\r\nNot Found";
            out.write(notFound.getBytes(StandardCharsets.UTF_8));
            out.flush();
        } catch (Exception e) {
            Log.e(TAG, "HTTP client error", e);
        } finally {
            try { client.close(); } catch (Exception ignored) {}
        }
    }

    private void refreshNetworkInfo() {
        String foundIp = "0.0.0.0";
        String foundBroadcast = "255.255.255.255";
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface intf : Collections.list(interfaces)) {
                if (!intf.isUp() || intf.isLoopback()) continue;
                for (InterfaceAddress ia : intf.getInterfaceAddresses()) {
                    InetAddress addr = ia.getAddress();
                    if (!addr.isLoopbackAddress() && addr instanceof Inet4Address) {
                        String ip = addr.getHostAddress();
                        if (ip != null && (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172."))) {
                            foundIp = ip;
                            if (ia.getBroadcast() != null) {
                                foundBroadcast = ia.getBroadcast().getHostAddress();
                            }
                            break;
                        }
                    }
                }
                if (!"0.0.0.0".equals(foundIp)) break;
            }
        } catch (Exception e) {
            Log.e(TAG, "IP lookup error", e);
        }
        myIp = foundIp;
        subnetBroadcastIp = foundBroadcast;
    }

    @Override
    protected void handleOnDestroy() {
        running = false;
        isTalking = false;
        if (scheduler != null) scheduler.shutdownNow();
        if (controlSocket != null) controlSocket.close();
        if (voiceSocket != null) voiceSocket.close();
        try { if (httpServerSocket != null) httpServerSocket.close(); } catch (Exception ignored) {}
        if (multicastLock != null && multicastLock.isHeld()) multicastLock.release();
        super.handleOnDestroy();
    }
}
