# K'Cho Chat v3 (Offline Local Wi-Fi Mesh Messenger)

Database နှင့် Internet မလိုဘဲ Wi-Fi Router သို့မဟုတ် Mobile Hotspot တစ်ခုတည်းပေါ်ရှိ Android ဖုန်းများကြား တိုက်ရိုက်ဆက်သွယ်နိုင်သော App ဖြစ်ပါသည်။

## ပါဝင်သော Features များ
- **Logo**: အောက်ချင်းငှက်မောင်နှံ တောင်ဇလပ်ပင်ကိုင်းပေါ်တွင် ထိုင်နေသော Emblem Design
- **Auto-Discovery & @ID Search**: Wi-Fi တူသူများကို အလိုအလျောက် ရှာဖွေပေးပြီး နာမည်၊ `@username` ID သို့မဟုတ် Local IP ဖြင့် ရှာဖွေ/ချိတ်ဆက်နိုင်ခြင်း
- **Group Chat & Direct Chat**: Wi-Fi တစ်ခုလုံးရှိ လူအားလုံးပါဝင်သော Group Chat နှင့် တစ်ဦးချင်း Direct Chat
- **Live Walkie-Talkie Voice Call**: `Hold` ခလုတ်နှိပ်ထားစဉ် UDP Audio Stream (16kHz PCM) ဖြင့် Speaker မှ တိုက်ရိုက် အသံထုတ်လွှင့်/နားထောင်နိုင်ခြင်း
- **Photo & Video Sharing**: Built-in Local HTTP Server (Port 8080) မှတစ်ဆင့် ပုံနှင့် Video ဖိုင်များကို တိုက်ရိုက် ပို့/လက်ခံနိုင်ခြင်း
