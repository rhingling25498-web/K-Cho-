package com.kcho.chat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.util.Base64;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@CapacitorPlugin(name = "KchoMesh", permissions = {
 @Permission(alias="network", strings={Manifest.permission.INTERNET, Manifest.permission.ACCESS_NETWORK_STATE, Manifest.permission.ACCESS_WIFI_STATE, Manifest.permission.CHANGE_WIFI_MULTICAST_STATE})
})
public class KchoMeshPlugin extends Plugin {
 private static final int UDP_PORT=39870, HTTP_PORT=39871;
 private volatile boolean running=false;
 private DatagramSocket udp;
 private ServerSocket server;
 private Thread udpThread,httpThread;
 private WifiManager.MulticastLock multicastLock;
 private final Map<String,byte[]> media=new ConcurrentHashMap<>();
 private final Map<String,String> mimeTypes=new ConcurrentHashMap<>();
 private String localIp="0.0.0.0";

 @PluginMethod public void startService(PluginCall call) {
  try {
   if (Build.VERSION.SDK_INT >= 23 && getContext().checkSelfPermission(Manifest.permission.INTERNET)!=PackageManager.PERMISSION_GRANTED) { /* normal permission */ }
   localIp=getLocalIp();
   if (!running) startServers();
   JSObject out=new JSObject(); out.put("ip",localIp); out.put("udpPort",UDP_PORT); out.put("httpPort",HTTP_PORT); call.resolve(out);
  } catch(Exception e){ call.reject("Mesh start failed: "+e.getMessage(),e); }
 }
 private synchronized void startServers() throws Exception {
  if(running)return; running=true;
  WifiManager wm=(WifiManager)getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
  if(wm!=null){ multicastLock=wm.createMulticastLock("kcho-mesh"); multicastLock.setReferenceCounted(false); multicastLock.acquire(); }
  udp=new DatagramSocket(null); udp.setReuseAddress(true); udp.setBroadcast(true); udp.bind(new InetSocketAddress(UDP_PORT));
  udpThread=new Thread(()->{ byte[] buf=new byte[65507]; while(running){ try{ DatagramPacket p=new DatagramPacket(buf,buf.length); udp.receive(p); String payload=new String(p.getData(),p.getOffset(),p.getLength(),java.nio.charset.StandardCharsets.UTF_8); JSObject evt=new JSObject();evt.put("payload",payload);evt.put("senderIp",p.getAddress().getHostAddress());notifyListeners("onPacket",evt); }catch(Exception ex){ if(running) android.util.Log.w("KchoMesh","UDP receive",ex); } }},"KchoUdp"); udpThread.start();
  server=new ServerSocket(); server.setReuseAddress(true); server.bind(new InetSocketAddress(HTTP_PORT));
  httpThread=new Thread(()->{ while(running){ try{ Socket s=server.accept(); new Thread(()->handleHttp(s),"KchoHttpClient").start(); }catch(Exception ex){if(running)android.util.Log.w("KchoMesh","HTTP accept",ex);} }},"KchoHttp"); httpThread.start();
 }
 @PluginMethod public void sendPacket(PluginCall call){ String payload=call.getString("payload");String target=call.getString("targetIp","255.255.255.255"); if(payload==null){call.reject("payload required");return;} try{ if(!running)startServers(); byte[] b=payload.getBytes(java.nio.charset.StandardCharsets.UTF_8); DatagramPacket p=new DatagramPacket(b,b.length,InetAddress.getByName(target),UDP_PORT);udp.send(p);call.resolve(); }catch(Exception e){call.reject("UDP send failed: "+e.getMessage(),e);} }
 @PluginMethod public void hostMediaBase64(PluginCall call){ try{String b64=call.getString("base64");String name=call.getString("fileName","media.bin");String mime=call.getString("mimeType","application/octet-stream");if(b64==null)throw new Exception("base64 required");if(!running)startServers();String id=UUID.randomUUID().toString();media.put(id,Base64.decode(b64,Base64.DEFAULT));mimeTypes.put(id,mime);JSObject o=new JSObject();o.put("url","http://"+localIp+":"+HTTP_PORT+"/media/"+id);o.put("fileName",name);call.resolve(o);}catch(Exception e){call.reject("Media host failed: "+e.getMessage(),e);} }
 @PluginMethod public void fetchMediaAsBase64(PluginCall call){String url=call.getString("url");if(url==null){call.reject("url required");return;}new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(30000);ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);}JSObject o=new JSObject();o.put("base64",Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP));call.resolve(o);c.disconnect();}catch(Exception e){call.reject("Media download failed: "+e.getMessage(),e);}}).start();}
 private void handleHttp(Socket s){try(Socket socket=s;BufferedReader r=new BufferedReader(new InputStreamReader(socket.getInputStream()));OutputStream out=socket.getOutputStream()){String line=r.readLine();if(line==null)return;String[] parts=line.split(" ");String path=parts.length>1?parts[1]:"/";while((line=r.readLine())!=null&&!line.isEmpty()){} if(path.startsWith("/media/")){String id=path.substring(7);byte[] data=media.get(id);if(data==null){writeHttp(out,404,"text/plain",new byte[0]);return;}writeHttp(out,200,mimeTypes.getOrDefault(id,"application/octet-stream"),data);}else writeHttp(out,404,"text/plain",new byte[0]);}catch(Exception e){android.util.Log.w("KchoMesh","HTTP client",e);}}
 private void writeHttp(OutputStream out,int status,String mime,byte[] data)throws IOException{String label=status==200?"OK":"Not Found";out.write(("HTTP/1.1 "+status+" "+label+"\r\nContent-Type: "+mime+"\r\nContent-Length: "+data.length+"\r\nConnection: close\r\nAccess-Control-Allow-Origin: *\r\n\r\n").getBytes("UTF-8"));out.write(data);out.flush();}
 @PluginMethod public void saveMediaToDownloads(PluginCall call){try{String b64=call.getString("base64");String name=call.getString("fileName","kcho-media.bin");byte[] bytes=Base64.decode(b64,Base64.DEFAULT);ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,name.toLowerCase().endsWith(".mp4")?"video/mp4":"image/jpeg");if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.Downloads.RELATIVE_PATH,android.os.Environment.DIRECTORY_DOWNLOADS+"/KChoChat");Uri uri=getContext().getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new Exception("Cannot create download");try(OutputStream os=getContext().getContentResolver().openOutputStream(uri)){os.write(bytes);}JSObject o=new JSObject();o.put("path","Downloads/KChoChat/"+name);call.resolve(o);}catch(Exception e){call.reject("Save failed: "+e.getMessage(),e);} }
 @PluginMethod public void getStorageUsage(PluginCall call){long n=0;for(byte[] b:media.values())n+=b.length;JSObject o=new JSObject();o.put("totalBytes",n);call.resolve(o);}
 @PluginMethod public void clearCacheAndMedia(PluginCall call){boolean include=call.getBoolean("includeSaved",false);long n=0;for(byte[] b:media.values())n+=b.length;media.clear();mimeTypes.clear();JSObject o=new JSObject();o.put("freedBytes",n);call.resolve(o);}
 @PluginMethod public void startTalking(PluginCall call){call.reject("Live voice streaming is not implemented in this build");}
 @PluginMethod public void stopTalking(PluginCall call){call.resolve();}
 private String getLocalIp(){try{Enumeration<NetworkInterface> it=NetworkInterface.getNetworkInterfaces();while(it.hasMoreElements()){NetworkInterface ni=it.nextElement();Enumeration<InetAddress> as=ni.getInetAddresses();while(as.hasMoreElements()){InetAddress a=as.nextElement();if(!a.isLoopbackAddress()&&a instanceof Inet4Address)return a.getHostAddress();}}}catch(Exception ignored){}return "0.0.0.0";}
 @Override protected void handleOnDestroy(){running=false;if(udp!=null)udp.close();try{if(server!=null)server.close();}catch(Exception ignored){}if(multicastLock!=null&&multicastLock.isHeld())multicastLock.release();super.handleOnDestroy();}
}
